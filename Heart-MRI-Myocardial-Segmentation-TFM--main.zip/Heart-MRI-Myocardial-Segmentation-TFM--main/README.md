## MRI Myocardial Segmentation (TFM)

This project contains notebooks and trained models for cardiac MRI segmentation (LV/RV walls, core and border-zone surfaces). It includes example predictions, 3D visualizations, and comparison tooling.

### Repository Structure
- `data.zip`: Full dataset (too large for Git LFS/GitHub). You must extract this before running anything.
- `data/`: Will appear after extracting `data.zip` (patient studies and masks in VTK).
- `models/`: Trained 3D U-Net weights (`.pth`).
- `output/`: Example predictions (segmentations and 3D meshes).
- `compare_predictions.ipynb`: Visual comparison and metrics (e.g., Dice) notebook.
- `predict (1).ipynb`: Inference notebook to generate predictions from models.
- `generator (1).ipynb`: Data preparation utilities.
- `test/`: Test masks and a study for quick checks.

### Quick Start
1) Clone the repo.
2) Extract `data.zip` into the project root so that a `data/` folder is created:

```bash
# Windows PowerShell (in repo root)
Expand-Archive -Path .\data.zip -DestinationPath .\
# After extraction, you should have .\data\pacienteX\... files
```

3) Set up a Python environment (recommended: Python 3.10+):

```bash
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

If `requirements.txt` is not provided, install typical dependencies used for 3D medical imaging and notebooks (adjust as needed):

```bash
pip install numpy scipy scikit-image matplotlib ipykernel ipywidgets torch torchvision torchaudio vtk pyvista nibabel tqdm
```

4) Open the notebooks and run:
- `compare_predictions.ipynb` to visualize GT vs. predictions and compute metrics.
- `predict (1).ipynb` to run inference using the models in `models/` and write outputs to `output/`.

### Large Files and Models
- The full dataset is provided as `data.zip` in the repository root; extract it before use.
- Trained `.pth` model files are stored under `models/`. If any files are missing, add them there before running inference.

### Results (Examples)
Place the following two images in `docs/images/` to have them render below (filenames must match):
- `docs/images/result_slice_overlay.png` — a 2D slice: original + GT (red) + prediction (blue) + overlay.
- `docs/images/result_3d_overlay.png` — a 3D mesh overlay of GT (red) vs. prediction (blue).

![2D Slice Overlay](docs/images/test.png)

![3D Overlay](docs/images/test_mask.png)

If you do not have these exact files yet, export them from `compare_predictions.ipynb` or use images from `output/` and save them to `docs/images/` with the filenames above.

### Reproducing Predictions
1) Ensure `data/` exists (unzipped) and models are present in `models/`.
2) Open `predict (1).ipynb` and set paths to the desired patient study in `data/`.
3) Run the notebook cells to generate segmentations and (optionally) 3D meshes in `output/`.
4) Use `compare_predictions.ipynb` to compute Dice and create figures.

### Notes
- Input and output volumetric files are in VTK format (`.vtk`).
- The repository includes example outputs under `output/` for quick visualization.

### Citation
If you use this repository, please include an appropriate citation to the corresponding thesis/report and to any third-party libraries you rely on (e.g., PyTorch, VTK/PyVista).


